var serverlessSDK = require('./serverless_sdk/index.js')
serverlessSDK = new serverlessSDK({
orgId: 'guuhh',
applicationName: 'emporiumapp',
appUid: 'GxZhcqKTcljYLfd1c5',
orgUid: 'Qq1RFR8j9CPNBMt5XY',
deploymentUid: '1ff7efad-3249-4f04-8c8d-55ee40d274ba',
serviceName: 'emporiumapp',
stageName: 'dev',
pluginVersion: '3.3.0'})
const handlerWrapperArgs = { functionName: 'emporiumapp-dev-hello', timeout: 6}
try {
  const userHandler = require('./handler.js')
  module.exports.handler = serverlessSDK.handler(userHandler.hello, handlerWrapperArgs)
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs)
}
